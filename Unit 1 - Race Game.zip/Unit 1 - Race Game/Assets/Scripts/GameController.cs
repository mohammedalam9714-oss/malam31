﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

	public GameObject firstPersonPlayer;
	public GameObject car;
	public GameObject carCamera;
	public GameObject messagePanel;
	public GameObject speedText;
	public GameObject timeText;

	public float goalSeconds = 30;
	private float timeElapsed = 0; // in seconds

	void Start()
    {
		messagePanel.SetActive(false);

		carCamera.GetComponent<AudioListener>().enabled = false;
		car.GetComponent<CarController>().enabled = false;
	}

	void Update() {
		timeElapsed += Time.deltaTime;
		if (timeElapsed > goalSeconds)
		{
			endGame();
			return;
		}

		if (Input.GetKeyDown(KeyCode.E)) {
			if (firstPersonPlayer.activeInHierarchy) {
				if (car.GetComponent<CarEntryZoneBehaviour>().isInEntryZone()) {
					enterCar();
					car.GetComponent<CarEntryZoneBehaviour>().setInEntryZone(false);
				}
			}
			else {
				exitCar();
				car.GetComponent<CarEntryZoneBehaviour>().setInEntryZone(true);
			}
		}

		UpdateHUD();
	}

	void UpdateHUD()
	{
		float timeRemaining = goalSeconds - timeElapsed;
		timeText.GetComponent<Text>().text = timeRemaining.ToString("F0");

		if (firstPersonPlayer.activeInHierarchy)
        {
			speedText.GetComponent<Text>().text = ""; // not in car
		}
		else{
			float currentSpeed = car.GetComponent<Rigidbody>().velocity.magnitude * 2.237f;
				// mulitply by 2.237 to convert from meters per second to miles per hour
			speedText.GetComponent<Text>().text = currentSpeed.ToString("F2") + " mph";
		}
	}

	void enterCar(){
		firstPersonPlayer.SetActive(false);
		car.GetComponent<CarController>().enabled = true;
		carCamera.GetComponent<AudioListener>().enabled = true;
		Debug.Log("In Car");
		car.GetComponent<CarEntryZoneBehaviour>().hideInstructions();
	}

	void exitCar(){
		firstPersonPlayer.transform.position = car.transform.position + new Vector3(0f, 2f, 4f);
		firstPersonPlayer.SetActive(true);
		car.GetComponent<CarController>().enabled = false;
		carCamera.GetComponent<AudioListener>().enabled = false;

		car.GetComponent<CarEntryZoneBehaviour>().showInstructions();
	}

	public void endGame()
	{
		string endMessage = "You Lost!";
		if (timeElapsed <= goalSeconds)
        {
			endMessage = "You win!\n\nYou completed the race in " + timeElapsed + " seconds!";
		}
		
		print(endMessage);
		messagePanel.SetActive(true);
		messagePanel.GetComponent<Text>().text = endMessage;

		Time.timeScale = 0;

		firstPersonPlayer.GetComponent<PlayerMovement>().enabled = false;
		car.GetComponent<CarController>().enabled = false;
		this.enabled = false;
	}

}
