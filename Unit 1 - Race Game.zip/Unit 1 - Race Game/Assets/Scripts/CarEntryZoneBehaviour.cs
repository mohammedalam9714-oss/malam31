using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarEntryZoneBehaviour : MonoBehaviour
{
	private bool inEntryZone;
	public GameObject messagePanel;
	public GameObject playerCharacter;

	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject == playerCharacter)
		{
			Debug.Log("Player entered car entry zone");
			inEntryZone = true;
			showInstructions();
		}
	}

	void OnTriggerExit(Collider other)
	{
		if (other.gameObject == playerCharacter)
		{
			Debug.Log("Player exited car entry zone");
			inEntryZone = false;
			hideInstructions();
		}
	}

	public void setInEntryZone(bool value)
	{
		inEntryZone = value;
	}

	public bool isInEntryZone()
	{
		return inEntryZone;
	}

	public void showInstructions()
	{
		messagePanel.SetActive(true);
	}

	public void hideInstructions()
	{
		messagePanel.SetActive(false);
	}
}
