using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyActivation : MonoBehaviour
{
    public GameObject target;
    public KeyCode key = KeyCode.F;

    void Update()
    {
        //target.SetActive(Input.GetKey(key));
        if (Input.GetKeyDown(key))
        {
            target.SetActive(!target.activeSelf);
        }
    }
}
