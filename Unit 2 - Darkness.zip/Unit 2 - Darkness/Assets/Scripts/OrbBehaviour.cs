using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrbBehaviour : MonoBehaviour
{

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Player")
        {
            print("YOU WIN");
            Time.timeScale = 0;
            other.gameObject.GetComponent<PlayerMovement>().enabled = false;
            this.gameObject.SetActive(false);
        }
    }
}
