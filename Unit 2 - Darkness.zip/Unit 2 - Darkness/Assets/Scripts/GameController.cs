using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public GameObject OrbPrefab;
    public GameObject water;

    void Start()
    {
        // spawn orb at random location on island
        Terrain terrain = Terrain.activeTerrain;
        Vector3 terrainSize = terrain.GetComponent<Terrain>().terrainData.size;
        Vector3 terrainPos = terrain.GetPosition();
        Vector3 orbPosition;
        float orbMaxY = 110f; // to avoid placement on mountains

        do
        {
            float orbX = Random.Range(terrainPos.x, terrainPos.x + terrainSize.x);
            float orbZ = Random.Range(terrainPos.z, terrainPos.z + terrainSize.z);

            orbPosition = new Vector3(orbX, 0, orbZ);
            orbPosition.y = terrain.SampleHeight(orbPosition) + terrainPos.y;

        } while (orbPosition.y < water.transform.position.y || orbPosition.y > orbMaxY);

        orbPosition.y += 1.5f;

        GameObject gameObject1 = Instantiate(OrbPrefab, orbPosition, Quaternion.identity);
    }
}
